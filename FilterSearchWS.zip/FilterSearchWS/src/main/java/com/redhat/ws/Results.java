package com.redhat.ws;

public class Results {
	
	private User[] results;

	public User[] getResults() {
		return results;
	}

	public void setResults(User[] results) {
		this.results = results;
	}



}
