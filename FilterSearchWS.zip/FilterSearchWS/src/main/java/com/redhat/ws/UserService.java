package com.redhat.ws;



import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

@Path("/users")
public class UserService {
	ObjectMapper objectMapper= new ObjectMapper();
	
	@GET	
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUsers() throws IOException, URISyntaxException
	{
		List<User> users=new ArrayList<User>(1);
		
		JsonNode resultsNode=readJsonFile("users.json");
		
		for(JsonNode userNode: resultsNode)
		{			
			addUsers(userNode, users);			
		}
		
		return users;
		
	}
	
	
	
	@GET
	@Path("/search")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUser(@QueryParam("email") String inputEmail, @QueryParam("filter") String inputFilter) throws IOException, URISyntaxException
	{
		List<User> users=new ArrayList<User>(1);
		JsonNode resultsNode=readJsonFile("users.json");
		if(inputEmail!= null)
		{
			for(JsonNode userNode: resultsNode)
			{
			String email=userNode.get("user").get("email").asText();
				
				if(email.equals(inputEmail))
				{
					addUsers(userNode, users);
				}
				
			}
		}else if(inputFilter != null)
		{
			Map<String, String> filtersMap=new HashMap<String, String>();
			String[] filters=inputFilter.split("\\|");
			
			 for(String filter: filters)
			 {
				 filtersMap.put(filter.split("::")[0], filter.split("::")[1]);
			 }
			 String gender;
			 String pps;
			 String phone;
			 boolean matched=false;
			 for(JsonNode userNode: resultsNode)
			 {
				 gender=userNode.get("user").get("gender").asText();
				 pps=userNode.get("user").get("pps").asText();
				 phone=userNode.get("user").get("phone").asText();
					
				 if(filtersMap.containsKey("gender"))
				 {					 
					 if(gender.equals(filtersMap.get("gender")))
					 {
						 matched=true;
					 }else{
						 matched=false;
					 }
				 }
				 
				 if(filtersMap.containsKey("pps"))
				 {					 
					 if(pps.equals(filtersMap.get("pps")))
					 {
						 matched=true;
						 
					 }else{
						 matched=false;
					 }
				 }
				 
				 if(filtersMap.containsKey("phone"))
				 {					 
					 if(phone.equals(filtersMap.get("phone")))
					 {
						 matched=true;
					 }else{
						 matched=false;
					 }
				 }
				
				 if(matched)
				 {
					 addUsers(userNode, users);
				 }
					
			 }
			
		}

		
		return users;
		
	}
	
	private void addUsers(JsonNode userNode, List<User> users) throws JsonMappingException, JsonParseException, IOException
	{
		User userObj= objectMapper.readValue(userNode.get("user"), User.class);		
		users.add(userObj);		
		
	}
	
	private JsonNode readJsonFile(String fileName) throws IOException, URISyntaxException
	{
		byte[] jsonbytes=Files.readAllBytes(Paths.get(this.getClass().getClassLoader().getResource(fileName).toURI()));
		JsonNode jsonNode=objectMapper.readTree(jsonbytes);
		JsonNode resultsNode=jsonNode.get("results");
		return resultsNode;
	}

}
 
